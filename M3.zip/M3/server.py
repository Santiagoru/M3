from mesa.visualization.ModularVisualization import ModularServer
from mesa.visualization.modules import CanvasGrid
from mesa.visualization.UserParam import UserSettableParameter

from agentes import Semaforo, Coche
from model import calle
#Creamos la apariencia de nuestros coches y semaforos
def tablero(agent):
    if agent is None:
        return

    visuales = { }

    if type(agent) is Semaforo:
        visuales["Layer"] = 1
        visuales["Color"] = agent.state
        visuales["Shape"] = "rect"
        visuales["Filled"] = "true"
        visuales["w"] = 1
        visuales["h"] = 1
    elif type(agent) is Coche:
        visuales["Layer"] = 1
        visuales["Color"] = ["#0051ff"]
        visuales["Shape"] = "rect"
        visuales["Filled"] = "true"
        visuales["w"] = 1
        visuales["h"] = 1

    return visuales
#Prametros de sliders y ventanas
canvas_element = CanvasGrid(tablero, 20, 20, 600, 600)

model_params = {
    "nVehicles": UserSettableParameter("slider", "Number of vehicles", 10, 1, 30)
}

server = ModularServer(
    calle, [canvas_element], "Traffic Simulation", model_params
)
server.port = 8521
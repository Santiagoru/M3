from model import calle
model = calle()
for i in range (100):
    model.step()